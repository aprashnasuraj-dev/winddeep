package core

import (
	"errors"
	"math/big"

	"github.com/electroneum/electroneum-sc/common"
	"github.com/electroneum/electroneum-sc/consensus/istanbul"
	qbfttypes "github.com/electroneum/electroneum-sc/consensus/istanbul/types"
	"github.com/electroneum/electroneum-sc/log"
)

// Returns true if the `proposal` for view (`sequence`, `round`) is justified by the set
// `roundChangeMessages` of ROUND-CHANGE messages and by the set `prepareMessages` of PREPARE messages.
// For this we must either have:
//   - a quorum of ROUND-CHANGE messages with preparedRound and preparedBlockDigest equal to nil; or
//   - a ROUND-CHANGE message (1) whose preparedRound is not nil and is equal or higher than the
//     preparedRound of `quorumSize` ROUND-CHANGE messages and (2) whose preparedRound and
//     preparedBlockDigest match the round and block of `quorumSize` PREPARE messages.
//
// Every ROUND-CHANGE message in the justification MUST itself be for the target view
// (`sequence`, `round`). The EEA QBFT specification's validRoundChange predicate requires the
// justification of a round-r PRE-PREPARE to consist of ROUND-CHANGE messages for round r; without
// this binding a proposer could replay valid ROUND-CHANGE messages from an earlier round (whose
// signatures correctly cover that earlier round) as the certificate for a new round. Note that a
// ROUND-CHANGE message's *own* round (the round it is changing TO) is distinct from its
// preparedRound (the round of any block it locked previously); only the former is bound here, while
// preparedRound is legitimately lower and is checked separately below.
func isJustified(
	sequence *big.Int,
	round *big.Int,
	proposal istanbul.Proposal,
	roundChangeMessages []*qbfttypes.SignedRoundChangePayload,
	prepareMessages []*qbfttypes.Prepare,
	quorumSize int,
	validators istanbul.ValidatorSet) error {
	// Check the size of the set of ROUND-CHANGE messages
	if len(roundChangeMessages) < quorumSize {
		return errors.New("number of roundchange messages is less than required quorum of messages")
	}

	// DoS hardening: justification cannot contain more round-change messages than there are validators
	if len(roundChangeMessages) > validators.Size() {
		return errors.New("too many round change messages in justification")
	}

	// View binding: every ROUND-CHANGE message must be for the same sequence and round as the
	// PRE-PREPARE it justifies. This is checked up front, before either quorum path, so that a
	// stale-but-validly-signed ROUND-CHANGE can never be counted toward quorum regardless of which
	// branch is taken below.
	if sequence == nil || round == nil {
		return errors.New("target sequence or round is nil")
	}
	for _, m := range roundChangeMessages {
		if m.Sequence == nil || m.Sequence.Cmp(sequence) != 0 {
			return errors.New("round change sequence does not match preprepare sequence")
		}
		if m.Round == nil || m.Round.Cmp(round) != 0 {
			return errors.New("round change round does not match preprepare round")
		}
	}

	// Count round change messages with "bad proposal" reason from DISTINCT signers
	badProposalSeen := make(map[common.Address]struct{})
	var hasBadProposalCount uint = 0
	for _, rcm := range roundChangeMessages {
		if rcm.HasBadProposal {
			src := rcm.Source()
			if src == (common.Address{}) {
				continue
			}
			if _, ok := badProposalSeen[src]; ok {
				continue
			}
			badProposalSeen[src] = struct{}{}
			hasBadProposalCount++
		}
	}
	hasBadProposal := hasBadProposalCount >= uint(quorumSize)

	// If there are PREPARE messages, require a quorum of DISTINCT, VALIDATOR-SET signers,
	// and require round/digest consistency.
	var preparedRound *big.Int
	if len(prepareMessages) > 0 {
		seen := make(map[common.Address]struct{}, len(prepareMessages))

		preparedRound = prepareMessages[0].Round
		if preparedRound == nil {
			return errors.New("prepared message has nil round (preparedRound)")
		}

		for _, p := range prepareMessages {
			if p.Round == nil {
				return errors.New("prepared message has nil round")
			}

			// Sequence binding: a justification PREPARE must belong to the same sequence as the
			// PRE-PREPARE it justifies. A PREPARE's signature covers its own Sequence, so a
			// genuine PREPARE from an already-finalised past sequence verifies correctly; without
			// this check its (matching) digest and round let it stand in as justification for a
			// block in the current sequence. Bind it here so replayed cross-sequence PREPAREs
			// cannot poison the prepared block.
			if p.Sequence == nil || p.Sequence.Cmp(sequence) != 0 {
				return errors.New("prepared message sequence does not match target sequence")
			}

			// Must be same round and match proposal digest (unless bad-proposal quorum)
			if preparedRound.Cmp(p.Round) != 0 || (proposal.Hash() != p.Digest && !hasBadProposal) {
				return errors.New("prepared messages do not have same round or do not match proposal")
			}

			// Must have a verified source set ( verifysignatures() )
			src := p.Source()
			if src == (common.Address{}) {
				return errors.New("prepared message has empty source (signature not verified)")
			}

			// Must be from a validator
			if _, v := validators.GetByAddress(src); v == nil {
				return errors.New("prepared message signer is not in validator set")
			}

			seen[src] = struct{}{}
		}

		// Must reach quorum of distinct signers
		if len(seen) < quorumSize {
			return errors.New("number of distinct prepared message signers is less than required quorum")
		}
	}

	if preparedRound == nil {
		return hasQuorumOfRoundChangeMessagesForNil(roundChangeMessages, quorumSize, validators)
	} else {
		return hasQuorumOfRoundChangeMessagesForPreparedRoundAndBlock(roundChangeMessages, preparedRound, proposal, quorumSize, hasBadProposal, validators)
	}
}

// Checks whether a set of ROUND-CHANGE messages has `quorumSize` messages from DISTINCT validators
// with nil prepared round and prepared block.
func hasQuorumOfRoundChangeMessagesForNil(roundChangeMessages []*qbfttypes.SignedRoundChangePayload, quorumSize int, validators istanbul.ValidatorSet) error {
	seen := make(map[common.Address]struct{})
	nilCount := 0
	for _, m := range roundChangeMessages {
		log.Trace("IBFT: hasQuorumOfRoundChangeMessagesForNil", "rc", m)

		src := m.Source()
		if src == (common.Address{}) {
			return errors.New("round change message has empty source (signature not verified)")
		}
		if _, v := validators.GetByAddress(src); v == nil {
			return errors.New("round change message signer is not in validator set")
		}
		if _, ok := seen[src]; ok {
			continue // skip duplicate signer
		}
		seen[src] = struct{}{}

		if (m.PreparedRound == nil || m.PreparedRound.Cmp(common.Big0) == 0) && common.EmptyHash(m.PreparedDigest) {
			nilCount++
			if nilCount == quorumSize {
				return nil
			}
		}
	}
	return errors.New("quorum of roundchange messages with nil prepared round not found")
}

// Checks whether a set of ROUND-CHANGE messages from DISTINCT validators has some message with
// `preparedRound` and `preparedBlockDigest`, and has `quorumSize` messages with prepared round
// equal to nil or equal or lower than `preparedRound`.
func hasQuorumOfRoundChangeMessagesForPreparedRoundAndBlock(roundChangeMessages []*qbfttypes.SignedRoundChangePayload, preparedRound *big.Int, preparedBlock istanbul.Proposal, quorumSize int, hasQuorumOfBadProposal bool, validators istanbul.ValidatorSet) error {
	seen := make(map[common.Address]struct{})
	lowerOrEqualRoundCount := 0
	hasMatchingMessage := false
	for _, m := range roundChangeMessages {
		log.Trace("IBFT: hasQuorumOfRoundChangeMessagesForPreparedRoundAndBlock", "rc", m)

		src := m.Source()
		if src == (common.Address{}) {
			return errors.New("round change message has empty source (signature not verified)")
		}
		if _, v := validators.GetByAddress(src); v == nil {
			return errors.New("round change message signer is not in validator set")
		}
		if _, ok := seen[src]; ok {
			continue // skip duplicate signer
		}
		seen[src] = struct{}{}

		if m.PreparedRound == nil || m.PreparedRound.Cmp(preparedRound) <= 0 {
			lowerOrEqualRoundCount++
			if m.PreparedRound != nil && m.PreparedRound.Cmp(preparedRound) == 0 && (m.PreparedDigest == preparedBlock.Hash() || (m.PreparedDigest != preparedBlock.Hash() && hasQuorumOfBadProposal)) {
				hasMatchingMessage = true
			}
			if lowerOrEqualRoundCount >= quorumSize && hasMatchingMessage {
				return nil
			}
		}
	}

	return errors.New("quorum of roundchange messages with prepared round and proposal not found")
}

// Checks whether the round and block of a set of PREPARE messages of at least quorumSize match the
// preparedRound and preparedBlockDigest of a ROUND-CHANGE message, AND ensures quorum of DISTINCT validators.
func hasMatchingRoundChangeAndPrepares(
	roundChange *qbfttypes.RoundChange,
	prepareMessages []*qbfttypes.Prepare,
	quorumSize int,
	hasBadProposal bool,
	validators istanbul.ValidatorSet,
) error {
	if len(prepareMessages) < quorumSize {
		return errors.New("number of prepare messages is less than quorum of messages")
	}

	// DoS hardening: justification cannot contain more prepares than there are validators
	if len(prepareMessages) > validators.Size() {
		return errors.New("too many prepare messages in justification")
	}

	if roundChange == nil {
		return errors.New("roundchange is nil")
	}
	if roundChange.PreparedRound == nil {
		return errors.New("roundchange has nil prepared round")
	}

	seen := make(map[common.Address]struct{}, len(prepareMessages))

	for _, p := range prepareMessages {
		if p == nil {
			return errors.New("prepare message is nil")
		}

		// Sequence binding: a justification PREPARE must belong to the same sequence as the
		// ROUND-CHANGE it justifies. A PREPARE's signature covers its own Sequence, so a genuine
		// PREPARE replayed from an already-finalised past sequence verifies correctly; without this
		// check its matching digest and round let it stand in as justification, poisoning
		// highestPreparedBlock with a stale block. Bind it to the ROUND-CHANGE's sequence here.
		if p.Sequence == nil || roundChange.Sequence == nil || p.Sequence.Cmp(roundChange.Sequence) != 0 {
			return errors.New("prepared message sequence does not match roundchange sequence")
		}

		// Must match digest (unless bad-proposal quorum)
		if p.Digest != roundChange.PreparedDigest && !hasBadProposal {
			return errors.New("prepared message digest does not match roundchange prepared digest")
		}

		// Must match prepared round
		if p.Round == nil {
			return errors.New("prepare message has nil round")
		}
		if p.Round.Cmp(roundChange.PreparedRound) != 0 {
			return errors.New("round number in prepared message does not match prepared round in roundchange")
		}

		// Must have a verified source set (i.e., verifySignatures ran)
		src := p.Source()
		if src == (common.Address{}) {
			return errors.New("prepared message has empty source (signature not verified)")
		}

		// Must be from a validator
		if _, v := validators.GetByAddress(src); v == nil {
			return errors.New("prepared message signer is not in validator set")
		}

		// Must be DISTINCT signers
		if _, ok := seen[src]; ok {
			return errors.New("duplicate prepare signer in justification")
		}
		seen[src] = struct{}{}
	}

	// Must reach quorum of distinct signers
	if len(seen) < quorumSize {
		return errors.New("number of distinct prepared message signers is less than required quorum")
	}

	return nil
}
